# Project-1-2

# How can I ensure that my code, program, or software is functional and secure?

I can write comprehensive unit tests and conduct regualr code reviews. I would also utilize code analysis tools.

# How do I interpret user needs and incorporate them into a program?
I should communicate effectilby with stakeholders and develop prototypes for user validation. Plus, conduct usability testing for feedback. 


# How do I approach designing software?

I would defnine clear objectives and scope. Also priorotize user-centric designs. 
