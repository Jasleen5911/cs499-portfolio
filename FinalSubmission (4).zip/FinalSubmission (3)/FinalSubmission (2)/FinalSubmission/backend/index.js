const mongoose = require('mongoose');
const express = require('express');
const cors = require('cors');



const mongoURI = 'mongodb://localhost:27017/contactsdb'; 

mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,

})
.then(() => console.log('MongoDB connected successfully'))
.catch(err => console.error('MongoDB connection error:', err));

const contactSchema = new mongoose.Schema({
    name: {type:String, required: true},
    email: {type: String, required: true }
});

const Contact = mongoose.model('Contact', contactSchema);

const app = express();
const port = 3002;

app.use(cors());
app.use(express.json());



app.get('/', (req, res) => {
   res.send('Hello from new-backend!');
});



app.get('/api/contacts', async (req, res) => {
    try {
        let results = await Contact.find();
    


    if(req.query.filter) {
        const filter = req.query.filter.toLowerCase();
        results = results.filter(c =>
            c.name.toLowerCase().includes(filter) ||
            c.email.toLowerCase().includes(filter)

        );
    }
    if(req.query.sort) {
        const [field,order] = req.query.sort.split('_');
        results = results.sort((a,b) => {
            if (a[field] < b[field]) return order === 'asc' ? -1: 1;
            if (a[field] > b[field]) return order === 'asc' ? 1: -1;
            return 0;
        });
    }


res.json(results);
} catch (err) {
    res.status(500).json({error: 'Server error' });
}
});

app.get('/api/contacts/search' , async (req, res) => {
    const query = req.query.q;
    if (!query) {
        return res.status(400).json({error: 'Query parameter q is required'});

    }

    try {

        const result = await Contact.findOne({name: {$regex: new RegExp(`^${query}$`, 'i') } });
    

if (result) {
    res.json(result);

} else {
    res.status(404).json({error: 'Contact not found'});
    }
} catch (err) {
    res.status(500).json({error: 'Server error'});
}
});


app.post('/api/contacts' , async (req, res) => {
    try {
    const newContact = new Contact(req.body);
    await newContact.save();
    res.status(201).json(newContact);
    } catch (err) {
        res.status(400).json({error: 'Invalid data' });
        
    }

});


app.put('/api/contacts/:id', async (req, res) => {
    try {

        const updatedContact = await Contact.findByIdAndUpdate(req.params.id, req.body, {new: true, runValidators: true});
        if (!updatedContact) {
     return res.status(404).json({error: 'Contact not found'});
        }
        res.json(updatedContact);
    } catch (err) {
        res.status(400).json({error: 'Invalid data'});
    }
});


app.delete('/api/contacts/:id', async (req, res) => {
    try {
        const deletedContact = await Contact.findByIdAndDelete(req.params.id);
        if (!deletedContact) {
            return res.status(404).json({error: 'Contact not found'});
        }
        res.status(204).end();
    } catch (err) {
        res.status(500).json({error: 'Server error'});

    }
});


app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);

});
